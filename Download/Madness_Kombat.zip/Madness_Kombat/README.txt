In configs.txt, set the first line as the current folder.

Enjoy the game!